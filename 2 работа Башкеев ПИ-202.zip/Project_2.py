import numpy as np
import scipy.linalg as la

#Ввод координатов 1-ого вектора
print('Введите координаты x, y, z вектора - A.')
a = []
for i in range(3):
    a.append([])
    for j in range(1):
        a[i] += [int(input())]

A = np.asarray(a)

#Ввод координатов 2-ого вектора
print('Введите координаты x, y, z вектора - B.')
b = []
for i in range(3):
    b.append([])
    for j in range(1):
        b[i] += [int(input())]

B = np.asarray(b)
#Функция для рассчёта скалярного произведения по формуле
def scalyre(A, B):
    return sum([A[i]*B[i] for i in range(3)])
#Функция для рассчёта векторного произведения по формуле
def vector(A, B):
    return (A[1]*B[2]-A[2]*B[1],A[2]*B[0]-A[0]*B[2], A[0]*B[1]-B[0]*A[1])

print('Скалярное произведение векторов: ' + str(scalyre(A, B)))
w = vector(A, B)
print('Векторное произведение векторов: ', w[0], w[1], w[2])