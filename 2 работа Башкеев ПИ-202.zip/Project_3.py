import numpy as np

a = np.array([[1, 2, 3, 4],
             [2, 2, -4, 5]])

b = np.array([[1, 1, 1, 2],
             [2, 3, 5, 6]])

c = (a * 3) - (b * 4)

print(c)
print('Наименьший элемент матрицы С: ' + str(c.min()))