import numpy as np

a = np.array([[2, -4],
              [3, 5],
              [-1, 0]])
A = a.transpose()
b = np.array([[1, 2, 7],
              [-3, -4, 0],
              [5, 2, 1]])
B = b.transpose()
c = np.array([[6, -3, 9],
              [4, -5, 2],
              [8, 1, 5]])
#Фуекция для умножения матриц
def matmult(a,b):
    zip_b = zip(*b)
    # uncomment next line if python 3 :
    zip_b = list(zip_b)
    return [[sum(ele_a*ele_b for ele_a, ele_b in zip(row_a, col_b))
             for col_b in zip_b] for row_a in a]

res1 = A * 2
res2 = matmult(c, A)
res3 = matmult(B, res1)
res = np.array(res2) - np.array(res3)
print('Минимальный элемент в матрице D: ' + str(res.min()))
