import numpy as np
import scipy.linalg as la
n = int(input('Введите размер матриц: '))
print('Введите значения для первой матрицы.')
#Ввод матриц через клавиатуру
a = []
for i in range(n):
    a.append([])
    for j in range(n):
        a[i] += [int(input())]

matrix_a = np.array(a) #Create array A
print('Введите значения для второй матрицы.')

b = []
for i in range(n):
    b.append([])
    for j in range(n):
        b[i] += [int(input())]

matrix_b = np.array(b) #Create array B

print("Вывод матрицы А:")
print(a)
print("Вывод матрицы B:")
print(b)

print('Определитель матрицы: ' + str(la.det(matrix_a))) #1
sum_diagonal = np.trace(matrix_a)
print('Сумма диагональных элементов: ' + str(sum_diagonal)) #2
w, v = np.linalg.eigh(matrix_a)
print('Собственные значения: ', w[0]) #3
print('Собственные вектора: ', v)
r = matrix_a.sum() - matrix_b.sum()
print('Разности суммы матриц: ' + str(r)) #4
print('Произведение матриц: ' + str(np.dot(matrix_a, matrix_b))) #5